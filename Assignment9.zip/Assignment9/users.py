import tkinter as tk 
from tkinter import * 
from tkinter.ttk import *
from tkinter import messagebox
import mysql.connector



connection = mysql.connector.connect(host='localhost', user='root', port='3306', password='shital2901', database='user_information')
c = connection.cursor()

def get_all_users():
    pass