from tkinter import *
import tkinter as tk
from tkinter import messagebox
import numpy as np
import pandas as pd
import mysql.connector
# import login as lg
#-------------------------------# from gui_stuff import *

diespred = ""
#-----------------------------


# main_win = Tk()
connection = mysql.connector.connect(host='localhost', user='root', port='3306', password='shital2901', database='user_information')
c = connection.cursor()
#-----------------------------------

def function1():
    l1=['back_pain','constipation','abdominal_pain','diarrhoea','mild_fever','yellow_urine',
    'yellowing_of_eyes','acute_liver_failure','fluid_overload','swelling_of_stomach',
    'swelled_lymph_nodes','malaise','blurred_and_distorted_vision','phlegm','throat_irritation',
    'redness_of_eyes','sinus_pressure','runny_nose','congestion','chest_pain','weakness_in_limbs',
    'fast_heart_rate','pain_during_bowel_movements','pain_in_anal_region','bloody_stool',
    'irritation_in_anus','neck_pain','dizziness','cramps','bruising','obesity','swollen_legs',
    'swollen_blood_vessels','puffy_face_and_eyes','enlarged_thyroid','brittle_nails',
    'swollen_extremeties','excessive_hunger','extra_marital_contacts','drying_and_tingling_lips',
    'slurred_speech','knee_pain','hip_joint_pain','muscle_weakness','stiff_neck','swelling_joints',
    'movement_stiffness','spinning_movements','loss_of_balance','unsteadiness',
    'weakness_of_one_body_side','loss_of_smell','bladder_discomfort','foul_smell_of urine',
    'continuous_feel_of_urine','passage_of_gases','internal_itching','toxic_look_(typhos)',
    'depression','irritability','muscle_pain','altered_sensorium','red_spots_over_body','belly_pain',
    'abnormal_menstruation','dischromic _patches','watering_from_eyes','increased_appetite','polyuria','family_history','mucoid_sputum',
    'rusty_sputum','lack_of_concentration','visual_disturbances','receiving_blood_transfusion',
    'receiving_unsterile_injections','coma','stomach_bleeding','distention_of_abdomen',
    'history_of_alcohol_consumption','fluid_overload','blood_in_sputum','prominent_veins_on_calf',
    'palpitations','painful_walking','pus_filled_pimples','blackheads','scurring','skin_peeling',
    'silver_like_dusting','small_dents_in_nails','inflammatory_nails','blister','red_sore_around_nose',
    'yellow_crust_ooze']

    disease=['Fungal infection','Allergy','GERD','Chronic cholestasis','Drug Reaction',
    'Peptic ulcer diseae','AIDS','Diabetes','Gastroenteritis','Bronchial Asthma','Hypertension',
    ' Migraine','Cervical spondylosis',
    'Paralysis (brain hemorrhage)','Jaundice','Malaria','Chicken pox','Dengue','Typhoid','hepatitis A',
    'Hepatitis B','Hepatitis C','Hepatitis D','Hepatitis E','Alcoholic hepatitis','Tuberculosis',
    'Common Cold','Pneumonia','Dimorphic hemmorhoids(piles)',
    'Heartattack','Varicoseveins','Hypothyroidism','Hyperthyroidism','Hypoglycemia','Osteoarthristis',
    'Arthritis','(vertigo) Paroymsal  Positional Vertigo','Acne','Urinary tract infection','Psoriasis',
    'Impetigo']

    l2=[]
    for x in range(0,len(l1)):
        l2.append(0)

    # -----------------------------------------TESTING DATA df -------------------------------------------------------------------------------------

    df=pd.read_csv("Testing.csv")

    df.replace({'prognosis':{'Fungal infection':0,'Allergy':1,'GERD':2,'Chronic cholestasis':3,'Drug Reaction':4,
    'Peptic ulcer diseae':5,'AIDS':6,'Diabetes ':7,'Gastroenteritis':8,'Bronchial Asthma':9,'Hypertension ':10,
    'Migraine':11,'Cervical spondylosis':12,
    'Paralysis (brain hemorrhage)':13,'Jaundice':14,'Malaria':15,'Chicken pox':16,'Dengue':17,'Typhoid':18,'hepatitis A':19,
    'Hepatitis B':20,'Hepatitis C':21,'Hepatitis D':22,'Hepatitis E':23,'Alcoholic hepatitis':24,'Tuberculosis':25,
    'Common Cold':26,'Pneumonia':27,'Dimorphic hemmorhoids(piles)':28,'Heart attack':29,'Varicose veins':30,'Hypothyroidism':31,
    'Hyperthyroidism':32,'Hypoglycemia':33,'Osteoarthristis':34,'Arthritis':35,
    '(vertigo) Paroymsal  Positional Vertigo':36,'Acne':37,'Urinary tract infection':38,'Psoriasis':39,
    'Impetigo':40}},inplace=True)


    X= df[l1]

    y = df[["prognosis"]]
    np.ravel(y)
    # print(y)

    # ------------------------------------TRAINING DATA tr --------------------------------------------------------------------------------

    tr=pd.read_csv("Testing.csv")
    tr.replace({'prognosis':{'Fungal infection':0,'Allergy':1,'GERD':2,'Chronic cholestasis':3,'Drug Reaction':4,
    'Peptic ulcer diseae':5,'AIDS':6,'Diabetes ':7,'Gastroenteritis':8,'Bronchial Asthma':9,'Hypertension ':10,
    'Migraine':11,'Cervical spondylosis':12,
    'Paralysis (brain hemorrhage)':13,'Jaundice':14,'Malaria':15,'Chicken pox':16,'Dengue':17,'Typhoid':18,'hepatitis A':19,
    'Hepatitis B':20,'Hepatitis C':21,'Hepatitis D':22,'Hepatitis E':23,'Alcoholic hepatitis':24,'Tuberculosis':25,
    'Common Cold':26,'Pneumonia':27,'Dimorphic hemmorhoids(piles)':28,'Heart attack':29,'Varicose veins':30,'Hypothyroidism':31,
    'Hyperthyroidism':32,'Hypoglycemia':33,'Osteoarthristis':34,'Arthritis':35,
    '(vertigo) Paroymsal  Positional Vertigo':36,'Acne':37,'Urinary tract infection':38,'Psoriasis':39,
    'Impetigo':40}},inplace=True)

    X_test= tr[l1]
    y_test = tr[["prognosis"]]
    np.ravel(y_test)


    def NaiveBayes():
        from sklearn.naive_bayes import GaussianNB
        gnb = GaussianNB()
        gnb=gnb.fit(X,np.ravel(y))

        # ----------------------------------calculating accuracy-------------------------------------------------------------------

        from sklearn.metrics import accuracy_score
        y_pred=gnb.predict(X_test)
        print(accuracy_score(y_test, y_pred))
        print(accuracy_score(y_test, y_pred,normalize=False))
        
        # -----------------------------------------------------

        psymptoms = [Symptom1.get(),Symptom2.get(),Symptom3.get(),Symptom4.get(),Symptom5.get()]
        for k in range(0,len(l1)):
            for z in psymptoms:
                if(z==l1[k]):
                    l2[k]=1

        inputtest = [l2]
        predict = gnb.predict(inputtest)
        predicted=predict[0]



        h='no'
        for a in range(0,len(disease)):
            if(predicted == a):
                h='yes'
                break

        if (h=='yes'):
            t3.delete("1.0", END)
            t3.insert(END, disease[a])
        else:
            t3.delete("1.0", END)
            t3.insert(END, "Not Found")
    
    
    # ------------------------------gui_stuff------------------------------------------------------------------------------------
    root = Tk()
    connection = mysql.connector.connect(host='localhost', user='root', port='3306', password='shital2901', database='user_information')
    c = connection.cursor()
    Symptom1 = StringVar(root)
    Symptom1.set(None)
    Symptom2 = StringVar(root)
    Symptom2.set(None)
    Symptom3 = StringVar(root)
    Symptom3.set(None)
    Symptom4 = StringVar(root)
    Symptom4.set(None)
    Symptom5 = StringVar(root)
    Symptom5.set(None)
    
    w = 470
    h = 550
    font14 = "-family {Segoe UI} -size 15 -weight bold -slant "  \
            "roman -underline 0 -overstrike 0"
    font16 = "-family {Swis721 BlkCn BT} -size 40 -weight bold "  \
        "-slant roman -underline 0 -overstrike 0"
    font9 = "-family {Segoe UI} -size 9 -weight normal -slant "  \
        "roman -underline 0 -overstrike 0"
    w2 = Label(root,text="        SMART DISEASE PREDICTOR", font= font14,fg="black", bg="#d9d9d9",highlightbackground="#d9d9d9",highlightcolor="black")
    w2.config(font=("Verdana", 30))
    w2.grid(row=1, column=0, columnspan=2, padx=100)


    S1Lb = Label(root, text="Symptom 1", fg="black", bg="white",height=2,font=font14)
    S1Lb.grid(row=8, column=1, pady=15, sticky=W)

    S2Lb = Label(root, text="Symptom 2", fg="black", bg="white",height=2,font=font14)
    S2Lb.grid(row=9, column=1, pady=15,sticky=W)

    S3Lb = Label(root, text="Symptom 3", fg="black", bg="white",height=2,font=font14)
    S3Lb.grid(row=10, column=1, pady=15,sticky=W)

    S4Lb = Label(root, text="Symptom 4", fg="black", bg="white",height=2,font=font14)
    S4Lb.grid(row=11, column=1, pady=15,sticky=W)

    S5Lb = Label(root, text="Symptom 5", fg="black", bg="white",height=2,font=font14)
    S5Lb.grid(row=12, column=1, pady=15,sticky=W)


    ranfLb = Label(root, text="Result", fg="white",font=font14, bg="red")
    ranfLb.grid(row=19, column=1, pady=15, sticky=W)

    # entries
    OPTIONS = sorted(l1)


    S1En = OptionMenu(root, Symptom1,*OPTIONS)
    S1En.grid(row=8, column=1)

    S2En = OptionMenu(root, Symptom2,*OPTIONS)
    S2En.grid(row=9, column=1)

    S3En = OptionMenu(root, Symptom3,*OPTIONS)
    S3En.grid(row=10, column=1)

    S4En = OptionMenu(root, Symptom4,*OPTIONS)
    S4En.grid(row=11, column=1)

    S5En = OptionMenu(root, Symptom5,*OPTIONS)
    S5En.grid(row=12, column=1)



    lr = Button(root, text="Predict",font=font14, command=NaiveBayes,bg="#d9d9d9",fg="black")
    lr.grid(row=20, column=1,padx=10)

    #textfileds

    t3 = Text(root, height=2, width=40,bg="orange",fg="black")
    t3.grid(row=19, column=1 , padx=10)

    root.mainloop()

def main_fun():
    # root = Tk()
    # width and height
    root = Tk()
    connection = mysql.connector.connect(host='localhost', user='root', port='3306', password='shital2901', database='user_information')
    c = connection.cursor()
    w = 475
    h = 525
    # background color
    bgcolor = "#d9d9d9"
    # ----------- CENTER FORM ------------- #

    root.overrideredirect(1) # remove border
    ws = root.winfo_screenwidth()
    hs = root.winfo_screenheight()
    x = (ws-w)/2
    y = (hs-h)/2
    root.geometry("%dx%d+%d+%d" % (w, h, x, y))

    # ----------- HEADER ------------- #

    headerframe = tk.Frame(root, highlightbackgroun='GREY', highlightcolor='GREY', 
                        highlightthickness=2, bg='#d9d9d9', width=w, height=70)
    titleframe = tk.Frame(headerframe, bg='GREY', padx=1, pady=1)
    title_label = tk.Label(titleframe, text='LOGIN', padx=20, pady=5, bg='#d9d9d9', 
                        fg='#000', font=('Tahoma',24), width=8)
    close_button = tk.Button(headerframe, text='x', borderwidth=1, relief='solid', 
                            font=('Verdana',12))

    headerframe.pack()
    titleframe.pack()
    title_label.pack()
    close_button.pack()

    titleframe.place(y=26, relx=0.5, anchor=CENTER)
    close_button.place(x=430, y=10)

    # close window
    def close_win():
        root.destroy()

    close_button['command'] = close_win

    # ----------- END HEADER ------------- #

    mainframe = tk.Frame(root, width=w, height=h)

    # ----------- Login Page ------------- #
    loginframe = tk.Frame(mainframe, width=w, height=h)
    login_contentframe = tk.Frame(loginframe, padx=30, pady=100, 
                        highlightbackgroun='GREY', highlightcolor='GREY', 
                        highlightthickness=2, bg=bgcolor)

    username_label = tk.Label(login_contentframe, text='USERNAME:', 
                            font=('Verdana',16), bg=bgcolor)
    password_label = tk.Label(login_contentframe, text='PASSWORD:', 
                            font=('Verdana',16), bg=bgcolor)

    username_entry = tk.Entry(login_contentframe, font=('Verdana',16))
    password_entry = tk.Entry(login_contentframe, font=('Verdana',16), show='*')

    login_button = tk.Button(login_contentframe,text="LOGIN", font=('Verdana',16), 
                            bg='#d9d9d9',fg='#000', padx=25, pady=10, width=25)

    go_register_label = tk.Label(login_contentframe, 
                        text="don't have an account? Create one" , 
                        font=('Verdana',10), bg=bgcolor, fg='blue')

    mainframe.pack(fill='both', expand=1)
    loginframe.pack(fill='both', expand=1)
    login_contentframe.pack(fill='both', expand=1)

    username_label.grid(row=0, column=0, pady=10)
    username_entry.grid(row=0, column=1)

    password_label.grid(row=1, column=0, pady=10)
    password_entry.grid(row=1, column=1)

    login_button.grid(row=2, column=0, columnspan=2, pady=40)

    go_register_label.grid(row=3, column=0, columnspan=2, pady=20)
    # create a function to display the register frame
    def go_to_register():
        loginframe.forget()
        registerframe.pack(fill="both", expand=1)
        title_label['text'] = 'Register'
        title_label['bg'] = '#d9d9d9'


    go_register_label.bind("<Button-1>", lambda page: go_to_register())

    # create a function to make the user login
    def login():
        username = username_entry.get().strip()
        password = password_entry.get().strip()
        vals = (username, password)
        select_query = "SELECT * FROM `users` WHERE `username` = %s and `password` = %s"
        c.execute(select_query, vals)
        user = c.fetchone()
        if user is not None:
            root.withdraw() # hide the root
            function1()
        else:
            messagebox.showwarning('Error','wrong username or password')

    login_button['command'] = login
    # ----------- Register Page ------------- #

    registerframe = tk.Frame(mainframe, width=w, height=h)
    register_contentframe = tk.Frame(registerframe, padx=15, pady=15, 
                            highlightbackgroun='GREY', highlightcolor='GREY', 
                            highlightthickness=2, bg=bgcolor)

    fullname_label_rg = tk.Label(register_contentframe, text='FULLNAME:', 
                                font=('Verdana',14), bg=bgcolor)
    username_label_rg = tk.Label(register_contentframe, text='USERNAME:', 
                                font=('Verdana',14), bg=bgcolor)
    password_label_rg = tk.Label(register_contentframe, text='PASSWORD:', 
                                font=('Verdana',14), bg=bgcolor)
    confirmpass_label_rg = tk.Label(register_contentframe, text='RE-PASSWORD:', 
                                    font=('Verdana',14), bg=bgcolor)
    phone_label_rg = tk.Label(register_contentframe, text='PHONE:', 
                            font=('Verdana',14), bg=bgcolor)
    gender_label_rg = tk.Label(register_contentframe, text='GENDER:', 
                            font=('Verdana',14), bg=bgcolor)



    fullname_entry_rg = tk.Entry(register_contentframe, font=('Verdana',14), width=22)
    username_entry_rg = tk.Entry(register_contentframe, font=('Verdana',14), width=22)
    password_entry_rg = tk.Entry(register_contentframe, font=('Verdana',14), width=22, 
                                show='*')
    confirmpass_entry_rg = tk.Entry(register_contentframe, font=('Verdana',14), width=22, 
                                    show='*')
    phone_entry_rg = tk.Entry(register_contentframe, font=('Verdana',14), width=22)

    radiosframe = tk.Frame(register_contentframe)
    gender = StringVar()
    gender.set('Male')
    male_radiobutton = tk.Radiobutton(radiosframe, text='Male', font=('Verdana',14), 
                                    bg=bgcolor, variable=gender, value='Male')
    female_radiobutton = tk.Radiobutton(radiosframe, text='Female', font=('Verdana',14), 
                                        bg=bgcolor, variable=gender, value='Female')


    register_button = tk.Button(register_contentframe,text="REGISTER", font=('Verdana',16)
                                , bg='#d9d9d9',fg='#000', padx=25, pady=10, width=25)

    go_login_label = tk.Label(register_contentframe, 
                            text="already have an account? sign in" , 
                            font=('Verdana',10), bg=bgcolor, fg='blue')

    register_contentframe.pack(fill='both', expand=1)

    fullname_label_rg.grid(row=0, column=0, pady=5, sticky='e')
    fullname_entry_rg.grid(row=0, column=1)

    username_label_rg.grid(row=1, column=0, pady=5, sticky='e')
    username_entry_rg.grid(row=1, column=1)

    password_label_rg.grid(row=2, column=0, pady=5, sticky='e')
    password_entry_rg.grid(row=2, column=1)

    confirmpass_label_rg.grid(row=3, column=0, pady=5, sticky='e')
    confirmpass_entry_rg.grid(row=3, column=1)

    phone_label_rg.grid(row=4, column=0, pady=5, sticky='e')
    phone_entry_rg.grid(row=4, column=1)

    gender_label_rg.grid(row=5, column=0, pady=5, sticky='e')
    radiosframe.grid(row=5, column=1)
    male_radiobutton.grid(row=0, column=0)
    female_radiobutton.grid(row=0, column=1)


    register_button.grid(row=7, column=0, columnspan=2, pady=20)

    go_login_label.grid(row=8, column=0, columnspan=2, pady=10)


    # create a function to display the login frame
    def go_to_login():
        registerframe.forget()
        loginframe.pack(fill="both", expand=1)
        title_label['text'] = 'Login'
        title_label['bg'] = '#d9d9d9'


    go_login_label.bind("<Button-1>", lambda page: go_to_login())
    # --------------------------------------- #

    # create a function to check if the username already exists
    def check_username(username):
        # username = username_entry_rg.get().strip()
        # vals = (username)
        # select_query = "SELECT * FROM `users` WHERE `username` = %s"
        # c.execute(select_query, vals)
        # user = c.fetchone()
        # if user is not None:
        #     return True
        # else:
        #     return False
        return False
    # --------------------------------------- #


    # create a function to register a new user
    def register():

        fullname = fullname_entry_rg.get().strip() # remove white space
        username = username_entry_rg.get().strip()
        password = password_entry_rg.get().strip()
        confirm_password = confirmpass_entry_rg.get().strip()
        phone = phone_entry_rg.get().strip()
        gdr = gender.get()
        
        

        if len(fullname) > 0 and  len(username) > 0 and len(password) > 0 and len(phone) > 0:
            if check_username(username) == False: 
                if password == confirm_password:
                    vals = (fullname, username, password, phone, gdr)
                    insert_query = "INSERT INTO `users`(`fullname`, `username`, `password`, `phone`, `gender`) VALUES (%s,%s,%s,%s,%s)"
                    c.execute(insert_query, vals)
                    connection.commit()
                    messagebox.showinfo('Register','your account has been created successfully')
                else:
                    messagebox.showwarning('Password','incorrect password confirmation')
            else:
                messagebox.showwarning('Duplicate Username','This Username Already Exists,try another one')
        else:
            messagebox.showwarning('Empty Fields','make sure to enter all the information')

    register_button['command'] = register

    # ------------------------------------------------------------------------ #
    
    # root = Tk()
    root.title("Smart Health disease predictor")
    # root.geometry('963x749+540+110')
    # root.resizable(0,0)
    root.configure(background='#d9d9d9')
    menub = Menu(root,background='#d9d9d9',fg='white') 
    root.config(menu=menub)
    menu_display=tk.Menu(menub,tearoff=0)
    # menub.add_cascade(label='User Account',menu=menu_display)
    # root = Tk()
    # history1 = Tk()
    # history1.geometry('963x749+540+110')
    # history1.resizable(0,0)
    menub = Menu(root,background='#d9d9d9',fg='white') 
    # history1.config(menu=menub)
    menu_display=tk.Menu(menub,tearoff=0)
    menub.add_cascade(label='User Account',menu=menu_display)
    def fun1():
        new_username = username_entry.get().strip()
        vals = [new_username]
        select_query = "SELECT disease from `history` WHERE `username` = %s " 
        c.execute(select_query, vals)
        user = c.fetchall()

        def displaying():
            win = Tk()
            win.title("Predicted History")
            win.geometry('963x749+540+110')
            i=4
            w2 = Label(win, justify=LEFT, text=new_username, fg="black",background="#d9d9d9")
            w2.config(font=("Elephant", 15))
            w2.grid(row=1, column=1, columnspan=2, padx=100)
            for student in user: 
                for j in range(len(student)):
                    e = Entry(win, justify=CENTER, fg='black',bg='white') 
                    e.grid(row=i, column=j) 
                    e.insert(END, student[j])
                i=i+1
            win.mainloop()
        displaying()
    menu_display.add_command(label='History',command=fun1)

    def history(result):
        new_username = username_entry.get().strip()
        pred_disease = result
        vals = [new_username,pred_disease]
        insert_query = "INSERT INTO `history` (`username`,`disease`) VALUES (%s,%s)" 
        c.execute(insert_query,vals)
        connection.commit()
        messagebox.showinfo('success','Successfully predicted')

    root.mainloop()

if __name__ == '__main__':
    v = main_fun()